def alphabet():
    alphabet=[chr(i) for i in range(97,123)]
    return alphabet

def alphabet_dic(alphabet):
    alphabet_dico = {alphabet[i] : i for i in range(len(alphabet))}
    alphabet_dico[' ']=26
    return alphabet_dico

def alphabet_dic_inverse(alphabet_dico):
    alphabet_dico_inverse=dict(zip(alphabet_dico.values(),alphabet_dico.keys()))
    return alphabet_dico_inverse

def liste_cles(cles): return [car for car in cles]

def format_cles(phrase, lst_cles, alphabet):
    cles_formatee = ""
    i = 0
    for car in phrase:
        if car in alphabet:
            cles_formatee += lst_cles[i]
            i = (i + 1) % len(lst_cles)
        elif car == ' ':
            cles_formatee += ' '
    return cles_formatee


def phrase_sans_accent(phrase):
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    cs = {'a': 'àãáâ','e': 'éèêë','i': 'îï','u': 'ùüû','o': 'ôöœ','y': 'ÿ','c': 'ç','oe': 'œ'}
    
    phrase = phrase.lower()
    sa_phrase = ''
    
    for car in phrase:
        if car in alphabet:
            sa_phrase += car
        elif car in 'àãáâéèêëîïùüûôöœÿç':
            for sa_lettre, accents in cs.items():
                if car in accents:
                    sa_phrase += sa_lettre
        elif car in ' ':
            sa_phrase += ' '
        elif car in "`~!@#$%^&*()-_=+[{]}\\|;:'\",<.>/?1234567890":
            pass
    
    return sa_phrase

def liste_ecart(sa_phrase,cles_formatee,alphabet_dico):
    lst_ecart_phrase = [alphabet_dico[car1] for car1 in sa_phrase]
    lst_ecart_cles = [alphabet_dico[car2] for car2 in cles_formatee]
    lst_ecart_vigenere = []
    for i in range(len(lst_ecart_phrase)):
        if lst_ecart_phrase[i]==26 and lst_ecart_cles[i]==26:
            lst_ecart_vigenere.append(26)
        else:
            lst_ecart_vigenere.append((lst_ecart_phrase[i] + lst_ecart_cles[i])%25)
    return lst_ecart_vigenere

def vigenere(lst_ecart_vigenere,alphabet_dico_inverse):
    phrase_vigenere=''
    for i in range(len(lst_ecart_vigenere)):
        phrase_vigenere += alphabet_dico_inverse[lst_ecart_vigenere[i]]
    return phrase_vigenere

def Debut():
    phrase = input('Veuillez saisir la phrase que vous voulez crypter : ')
    cles = input('Veuillez saisir la clés (permettant de crypter votre phrase) : ')
    lst_cles = liste_cles(cles)
    phrase_ss_accent = phrase_sans_accent(phrase)
    lst_cles_form = format_cles(phrase_ss_accent,lst_cles,alphabet())
    lst_ecart = liste_ecart(phrase_ss_accent,lst_cles_form,alphabet_dic(alphabet()))
    chiffre_vigenere = vigenere(lst_ecart, alphabet_dic_inverse(alphabet_dic(alphabet())))
    print("Le chiffrement Vigenere correspond à : ",chiffre_vigenere)

Debut()

