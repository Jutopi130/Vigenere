def alphabet():
    alphabet=[chr(i) for i in range(97,123)]
    return alphabet

def alphabet_dic(alphabet):
    alphabet_dico = {alphabet[i] : i for i in range(len(alphabet))}
    alphabet_dico[' ']=26
    return alphabet_dico

def alphabet_dic_inverse(alphabet_dico):
    alphabet_dico_inverse=dict(zip(alphabet_dico.values(),alphabet_dico.keys()))
    return alphabet_dico_inverse

def liste_cles(cles): return [car for car in cles]

def format_cles(chiffre_vigenere, lst_cles, alphabet):
    cles_formatee = ""
    i = 0
    for car in chiffre_vigenere:
        if car in alphabet:
            cles_formatee += lst_cles[i]
            i = (i + 1) % len(lst_cles)
        elif car == ' ':
            cles_formatee += ' '
    return cles_formatee

def liste_ecart(chiffre_vigenere,cles_formatee,alphabet_dico):
    lst_ecart_vigenere = [alphabet_dico[car1] for car1 in chiffre_vigenere]
    lst_ecart_cles = [alphabet_dico[car2] for car2 in cles_formatee]
    lst_ecart_phrase = []
    for i in range(len(lst_ecart_vigenere)):
        if lst_ecart_vigenere[i]==26 and lst_ecart_cles[i]==26:
            lst_ecart_phrase.append(26)
        else:
            lst_ecart_phrase.append((lst_ecart_vigenere[i] - lst_ecart_cles[i])%25)
    return lst_ecart_phrase

def phrase(lst_ecart_phrase,alphabet_dico_inverse):
    phrase=''
    for i in range(len(lst_ecart_phrase)):
        phrase += alphabet_dico_inverse[lst_ecart_phrase[i]]
    return phrase

def Debut():
    chiffre_vigenere = input('Veuillez saisir la phrase que vous voulez crypter : ')
    cles = input('Veuillez saisir la clés (permettant de crypter votre phrase) : ')
    lst_cles = liste_cles(cles)
    lst_cles_form = format_cles(chiffre_vigenere,lst_cles,alphabet())
    lst_ecart = liste_ecart(chiffre_vigenere,lst_cles_form,alphabet_dic(alphabet()))
    vigenere = phrase(lst_ecart, alphabet_dic_inverse(alphabet_dic(alphabet())))
    print("La phrase avant le chiffrement de Vigenere était : ",vigenere)

Debut()

